export const getTeamImage = (constructorId) => {
  const teamImages = {
    mercedes: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/mercedes.png',
    ferrari: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/ferrari.png',
    red_bull: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/red-bull.png',
    mclaren: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/mclaren.png',
    alpine: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/alpine.png',
    aston_martin: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/aston-martin.png',
    alpha_tauri: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/alphatauri.png',
    sauber: 'https://www.sportmonks.com/wp-content/uploads/2024/03/kick-sauber-team-logo.png',
    haas: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/haas.png',
    williams: 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/williams.png',
  };

  return teamImages[constructorId] || 'https://media.formula1.com/content/dam/fom-website/2018-redesign-assets/team%20logos/default.png';
};