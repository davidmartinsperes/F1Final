import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@f1_user_data';

// Function to save user data
export const saveUserData = async (data) => {
  try {
    const jsonValue = JSON.stringify(data);
    await AsyncStorage.setItem(STORAGE_KEY, jsonValue);
  } catch (e) {
    console.error('Error saving user data:', e);
  }
};

// Function to retrieve user data
export const getUserData = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : null;
  } catch (e) {
    console.error('Error retrieving user data:', e);
  }
};

// Function to remove user data
export const removeUserData = async () => {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Error removing user data:', e);
  }
};