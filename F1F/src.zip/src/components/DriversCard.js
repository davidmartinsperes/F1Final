import React from 'react';
import { View, Text, FlatList, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import { auth, db } from '../../firebaseConfig';
import { doc, updateDoc } from 'firebase/firestore';

const teams = [
  {
    id: "1",
    Equipe: "Scuderia Ferrari HP",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_auto,w_1320/content/dam/fom-website/2018-redesign-assets/team%20logos/ferrari",
    Pilotos: ["Lewis Hamilton #44", "Charles Leclerc #16"],
  },
  {
    id: "2",
    Equipe: "Mclaren F1 Team",
    image: "https://brandlogos.net/wp-content/uploads/2022/04/mclaren_formula_1_team-logo-brandlogos.net_.png",
    Pilotos: ["Lando Norris #4", "Oscar Piastri #81"],
  },
  {
    id: "3",
    Equipe: "Mercedes-AMG Petronas Formula One Team",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_75,w_1320/content/dam/fom-website/2018-redesign-assets/team%20logos/mercedes",
    Pilotos: ["George Russel #63", "Kimi Antonelli #12"],
  },
  {
    id: "4",
    Equipe: "Red Bull Racing",
    image: "https://brandlogo.org/wp-content/uploads/2024/04/Oracle-Red-Bull-Racing-Logo-300x300.png.webp",
    Pilotos: ["Max Verstappen #1", "Yuki Tsunoda #22"],
  },
  {
    id: "5",
    Equipe: "Aston Martin Aramco Formula One Team",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_auto,w_1320/content/dam/fom-website/2018-redesign-assets/team%20logos/aston%20martin",
    Pilotos: ["Fernando Alonso #14", "Lance Stroll #18"],
  },
  {
    id: "6",
    Equipe: "Stake F1 Team Kick Sauber",
    image: "https://www.sportmonks.com/wp-content/uploads/2024/03/kick-sauber-team-logo.png",
    Pilotos: ["Gabriel Bortoleto #5", "Nico Hulkenberg #27"],
  },
  {
    id: "7",
    Equipe: "Visa Cash App Racing Bulls Formula One Team",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_auto,w_1320/fom-website/2018-redesign-assets/team%20logos/racing%20bulls",
    Pilotos: ["Isack Hadjar #6", "Liam Lawson #30"],
  },
  {
    id: "8",
    Equipe: "MoneyGram Haas F1 Team",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_75,w_1320/content/dam/fom-website/2018-redesign-assets/team%20logos/haas",
    Pilotos: ["Esteban Ocon #31", "Oliver Bearman #87"],
  },
  {
    id: "9",
    Equipe: "BWT Alpine F1 Team",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_75,w_1320/content/dam/fom-website/2018-redesign-assets/team%20logos/alpine",
    Pilotos: ["Jack Doohan #7", "Pierre Gasly #10"],
  },
  {
    id: "10",
    Equipe: "Willians Racing",
    image: "https://media.formula1.com/image/upload/f_auto,c_limit,q_auto,w_1320/content/dam/fom-website/2018-redesign-assets/team%20logos/williams",
    Pilotos: ["Carlos Sainz #55", "Alexander Albon #23"],
  },
];

const drivers = teams.flatMap(team =>
  team.Pilotos.map(piloto => ({
    id: `${team.id}-${piloto}`,
    name: piloto,
    team: team.Equipe,
    image: team.image,
  }))
);

export default function DriversCard() {
  // Função para salvar favorito no Firestore
  const handleSaveFavorite = async (driver) => {
    const user = auth.currentUser;
    if (user) {
      await updateDoc(doc(db, 'users', user.uid), {
        favoriteDriver: {
          name: driver.name,
          image: driver.image,
        },
      });
      Alert.alert('Sucesso', 'Piloto salvo como favorito!');
    } else {
      Alert.alert('Erro', 'Você precisa estar logado para salvar um favorito.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Pilotos da Temporada</Text>
      <FlatList
        data={drivers}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() =>
              Alert.alert(
                'Favorito',
                'Deseja salvar este piloto como seu favorito?',
                [
                  { text: 'Cancelar', style: 'cancel' },
                  {
                    text: 'Salvar',
                    onPress: () => handleSaveFavorite(item),
                  },
                ]
              )
            }
          >
            <View style={styles.card}>
              <Image source={{ uri: item.image }} style={styles.logo} />
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.team}>Equipe: {item.team}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 10, textAlign: 'center' },
  card: { backgroundColor: '#fff', padding: 16, marginVertical: 8, borderRadius: 10, elevation: 3, alignItems: 'center' },
  logo: { width: 60, height: 60, marginBottom: 8, resizeMode: 'contain' },
  name: { fontSize: 16, fontWeight: 'bold', marginBottom: 4, textAlign: 'center' },
  team: { fontSize: 14, color: '#555', textAlign: 'center' },
});