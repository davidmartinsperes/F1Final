import React from 'react';
import { View, Text, FlatList, Image, StyleSheet, ActivityIndicator } from 'react-native';
import useFetch from '../hooks/useFetch';

export default function TeamCard() {
  const { data, loading, error } = useFetch('https://www.thesportsdb.com/api/v1/json/3/search_all_teams.php?l=Formula%201');

  if (loading) return <ActivityIndicator size="large" color="#d00" style={{ flex: 1, justifyContent: 'center' }} />;
  if (error) return <Text>Erro ao carregar equipes.</Text>;
  if (!data || !data.teams) return <Text>Nenhuma equipe encontrada.</Text>;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Equipes de F1 (TheSportsDB)</Text>
      <FlatList
        data={data.teams}
        keyExtractor={item => item.idTeam}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.strTeamBadge }} style={styles.logo} />
            <Text style={styles.team}>{item.strTeam}</Text>
            <Text style={styles.desc}>{item.strDescriptionEN?.slice(0, 100) || ''}...</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 10, textAlign: 'center' },
  card: { backgroundColor: '#f9f9f9', padding: 16, marginVertical: 8, borderRadius: 10, alignItems: 'center', elevation: 2 },
  logo: { width: 80, height: 80, marginBottom: 8, resizeMode: 'contain' },
  team: { fontSize: 16, fontWeight: 'bold', marginBottom: 4, textAlign: 'center' },
  desc: { fontSize: 12, color: '#333', textAlign: 'center' },
});