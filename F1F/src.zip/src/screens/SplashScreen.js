import React, { useEffect } from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../../firebaseConfig';

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        navigation.replace('Home');
      } else {
        navigation.replace('Login');
      }
    });
    return unsubscribe;
  }, []);

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://logos-world.net/wp-content/uploads/2023/12/F1-Logo.png' }}
        style={styles.logo}
        resizeMode="contain"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  logo: { width: 200, height: 100 },
});