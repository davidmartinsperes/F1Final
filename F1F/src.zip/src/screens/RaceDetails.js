import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function RaceDetails({ route }) {
  const { race } = route.params;
  return (
    <View style={styles.container}>
      <Image source={{ uri: race.image }} style={styles.img} />
      <Text style={styles.title}>{race.title}</Text>
      {race.text.map((line, idx) => (
        <Text key={idx} style={styles.info}>{line}</Text>
      ))}
      <Text style={styles.info}>Voltas: {race.laps || 'N/A'}</Text>
      <Text style={styles.info}>Último Campeão: {race.lastWinner || 'N/A'}</Text>
      <Text style={styles.info}>Recorde de Volta: {race.lapRecord || 'N/A'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff', alignItems: 'center' },
  img: { width: 220, height: 120, borderRadius: 8, marginBottom: 10, resizeMode: 'contain' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10, textAlign: 'center' },
  info: { fontSize: 16, color: '#555', textAlign: 'center', marginBottom: 4 },
});