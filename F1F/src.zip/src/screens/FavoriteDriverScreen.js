import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

export default function FavoriteDriverScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Piloto Favorito</Text>
      <Text style={styles.text}>Equipe: Ferrari</Text>
      <Text style={styles.text}>Nome: Charles Leclerc</Text>
      <Text style={styles.text}>Nacionalidade: Mônaco</Text>
      <Image
        source={{ uri: 'https://media.formula1.com/image/upload/f_auto/q_auto/v1684928737/fom-website/drivers/2023Drivers/leclerc.jpg' }}
        style={styles.img}
      />
      <Text style={styles.caption}>Meu Piloto Favorito</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  text: { fontSize: 16, marginBottom: 5 },
  img: { width: 200, height: 200, borderRadius: 8, marginVertical: 16 },
  caption: { fontSize: 14, color: '#555', textAlign: 'center' },
});