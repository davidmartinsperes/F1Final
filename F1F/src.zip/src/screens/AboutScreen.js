import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function AboutScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sobre a Fórmula 1</Text>
      <Text style={styles.text}>
        Fórmula 1 é a principal categoria do automobilismo mundial, composta por equipes e pilotos que competem em circuitos ao redor do mundo. Os carros são altamente tecnológicos e as corridas são conhecidas por sua velocidade, estratégia e emoção. A temporada é composta por várias etapas (Grandes Prêmios), e o campeão é definido por um sistema de pontos ao longo do ano.
      </Text>
      <Text style={styles.text}>
        A F1 é famosa por sua inovação, rivalidades históricas e fãs apaixonados. Além da competição, é um laboratório de tecnologia para a indústria automotiva.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  text: { fontSize: 16, marginBottom: 10, textAlign: 'justify' },
});