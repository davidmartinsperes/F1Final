import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import SplashScreen from '../screens/SplashScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import Dashboard from '../screens/Dashboard';
import Profile from '../screens/Profile';
import AboutScreen from '../screens/AboutScreen';
import FavoriteDriverScreen from '../screens/FavoriteDriverScreen';
import TeamCard from '../components/TeamCard';
import DriversCard from '../components/DriversCard';
import RaceDetails from '../screens/RaceDetails';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function DrawerRoutes() {
  return (
    <Drawer.Navigator initialRouteName="Dashboard">
      <Drawer.Screen name="Dashboard" component={Dashboard} options={{ title: 'Início' }} />
      <Drawer.Screen name="Profile" component={Profile} options={{ title: 'Perfil' }} />
      <Drawer.Screen name="TeamCard" component={TeamCard} options={{ title: 'Ver Equipes' }} />
      <Drawer.Screen name="DriversCard" component={DriversCard} options={{ title: 'Ver Pilotos' }} />
    </Drawer.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
      <Stack.Screen name="Home" component={DrawerRoutes} />
      <Stack.Screen name="About" component={AboutScreen} />
      <Stack.Screen name="FavoriteDriver" component={FavoriteDriverScreen} />
      <Stack.Screen name="RaceDetails" component={RaceDetails} />
    </Stack.Navigator>
  );
}